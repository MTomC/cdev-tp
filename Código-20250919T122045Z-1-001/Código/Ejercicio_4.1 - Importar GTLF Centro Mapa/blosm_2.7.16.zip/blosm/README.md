## Important!
Unless you are a developer, please get the addon [here](https://github.com/vvoovv/blender-osm/#blender-osm-openstreetmap-and-terrain-for-blender).
