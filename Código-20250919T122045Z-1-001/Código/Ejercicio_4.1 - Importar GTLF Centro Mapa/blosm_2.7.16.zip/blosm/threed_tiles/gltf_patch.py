
def select_imported_objects_4_1(gltf):
    return